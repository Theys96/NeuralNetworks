The figures in the corresponding report are directly related to some matlab script:
 - Figure 3: exp0.m
 - Figure 4: exp1.m
 - Figure 5: exp2a.m
 - Figure 6: exp2b.m

 All these Matlab scripts can be run as they are.
