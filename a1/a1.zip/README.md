The figures in the corresponding report are directly related to some matlab script:
 - Figure 2: exp1_N20.m
 - Figure 3: exp1_N100.m
 - Figure 4: exp1_N4.m
 - Figure 5: exp2.m

 All these Matlab scripts can be run as they are.
